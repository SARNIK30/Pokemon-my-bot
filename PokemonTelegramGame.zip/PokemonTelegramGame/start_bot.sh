#!/bin/bash

# Скрипт для ручного запуска Telegram бота Pokemon
# Автор: Replit AI

echo "Запуск Telegram бота Pokemon в режиме поллинга..."
echo "Логи будут выводиться в консоль."
echo "Для остановки нажмите Ctrl+C."
echo "---------------------------------------------"

python run_polling_bot.py