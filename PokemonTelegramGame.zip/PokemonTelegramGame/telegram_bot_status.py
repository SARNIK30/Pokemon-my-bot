#!/usr/bin/env python3
"""
Скрипт для проверки статуса Telegram бота и связанных конфигураций
"""

import os
import logging
import requests
from config import BOT_TOKEN, WEBHOOK_URL, ADMIN_IDS

# Настройка логирования
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_telegram_token():
    """Проверка токена Telegram"""
    logger.info("Проверка токена Telegram...")
    try:
        response = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getMe")
        if response.status_code == 200:
            data = response.json()
            if data["ok"]:
                bot_info = data["result"]
                logger.info(f"Токен верный! Бот: {bot_info['first_name']} (@{bot_info.get('username', 'N/A')})")
                return True
            else:
                logger.error(f"Telegram API вернул ошибку: {data['description']}")
        else:
            logger.error(f"Ошибка HTTP: {response.status_code} {response.text}")
    except Exception as e:
        logger.error(f"Ошибка при проверке токена: {e}")
    return False

def check_webhook_url():
    """Проверка URL вебхука"""
    logger.info(f"Проверка URL вебхука: {WEBHOOK_URL}")
    try:
        # Базовая проверка формата URL
        if not WEBHOOK_URL.startswith("https://"):
            logger.warning("URL вебхука должен начинаться с https://")
            return False
        
        # Попытка получить информацию о текущем вебхуке
        response = requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getWebhookInfo")
        if response.status_code == 200:
            data = response.json()
            if data["ok"]:
                webhook_info = data["result"]
                logger.info(f"Текущий URL вебхука: {webhook_info.get('url', 'Не установлен')}")
                if not webhook_info.get('url'):
                    logger.info("Вебхук не настроен (бот работает в режиме поллинга)")
                else:
                    if webhook_info.get('last_error_date'):
                        logger.warning(f"Последняя ошибка вебхука: {webhook_info.get('last_error_message', 'Неизвестно')}")
                return True
            else:
                logger.error(f"Telegram API вернул ошибку: {data['description']}")
        else:
            logger.error(f"Ошибка HTTP: {response.status_code} {response.text}")
    except Exception as e:
        logger.error(f"Ошибка при проверке вебхука: {e}")
    return False

def check_admin_ids():
    """Проверка списка ID администраторов"""
    logger.info(f"Проверка ID администраторов: {ADMIN_IDS}")
    if not ADMIN_IDS or (len(ADMIN_IDS) == 1 and ADMIN_IDS[0] == 12345678):
        logger.warning("ID администраторов не настроены или используется значение по умолчанию")
        return False
    return True

def check_data_directory():
    """Проверка наличия и доступа к директории данных"""
    data_dir = "data"
    logger.info(f"Проверка директории данных: {data_dir}")
    if not os.path.exists(data_dir):
        logger.warning(f"Директория {data_dir} не существует")
        try:
            os.makedirs(data_dir)
            logger.info(f"Создана директория {data_dir}")
        except Exception as e:
            logger.error(f"Ошибка при создании директории: {e}")
            return False
    else:
        logger.info(f"Директория {data_dir} существует")
        # Проверка доступа на запись
        try:
            test_file = os.path.join(data_dir, ".test_write")
            with open(test_file, "w") as f:
                f.write("test")
            os.remove(test_file)
            logger.info(f"Директория {data_dir} доступна для записи")
        except Exception as e:
            logger.error(f"Ошибка при проверке доступа на запись: {e}")
            return False
    return True

def check_replit_configuration():
    """Проверка конфигурации Replit"""
    logger.info("Проверка конфигурации Replit...")
    running_on_replit = bool(os.environ.get("REPL_ID"))
    
    if not running_on_replit:
        logger.info("Не выполняется на платформе Replit")
        return True
    
    logger.info("Выполняется на платформе Replit")
    
    # Проверка наличия необходимых скриптов для workflow
    workflow_script = ".config/workflow/run"
    pokebot_script = "pokebot.sh"
    
    workflow_exists = os.path.exists(workflow_script)
    pokebot_exists = os.path.exists(pokebot_script)
    
    if not workflow_exists:
        logger.warning(f"Скрипт Workflow не найден: {workflow_script}")
    else:
        logger.info(f"Скрипт Workflow существует: {workflow_script}")
    
    if not pokebot_exists:
        logger.warning(f"Скрипт запуска бота не найден: {pokebot_script}")
    else:
        logger.info(f"Скрипт запуска бота существует: {pokebot_script}")
    
    # Проверка доступности Always On
    if "REPLIT_OWNER" in os.environ:
        logger.info("Возможность настройки Always On доступна")
    else:
        logger.warning("Возможность настройки Always On может быть недоступна")
    
    return workflow_exists and pokebot_exists

if __name__ == "__main__":
    print("=== Проверка конфигурации Telegram бота ===")
    token_ok = check_telegram_token()
    webhook_ok = check_webhook_url()
    admin_ok = check_admin_ids()
    data_ok = check_data_directory()
    replit_ok = check_replit_configuration()
    
    print("\n=== Итоги проверки ===")
    print(f"Токен Telegram: {'✅' if token_ok else '❌'}")
    print(f"URL вебхука: {'✅' if webhook_ok else '❌'}")
    print(f"ID администраторов: {'✅' if admin_ok else '❌'}")
    print(f"Директория данных: {'✅' if data_ok else '❌'}")
    print(f"Конфигурация Replit: {'✅' if replit_ok else '❌'}")
    
    if token_ok and webhook_ok and admin_ok and data_ok and replit_ok:
        print("\n✅ Все проверки пройдены успешно! Бот должен работать корректно.")
    else:
        print("\n⚠️ Некоторые проверки не пройдены. Проверьте предупреждения выше.")
