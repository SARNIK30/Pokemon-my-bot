#!/bin/bash
# Скрипт для остановки бота в режиме Workflow на Replit

echo "===== Остановка Pokémon бота ====="
echo "Дата и время: $(date)"

# Проверка, существует ли файл heartbeat
if [ ! -f "bot_running.txt" ] && [ ! -f "bot_pid.txt" ]; then
    echo "⚠️ Файлы heartbeat и PID не существуют. Возможно, бот не запущен."
    echo "Все равно попытаемся остановить процессы..."
fi

# Остановка через PID файл
if [ -f "bot_pid.txt" ]; then
    BOT_PID=$(cat bot_pid.txt)
    echo "Остановка бота с PID $BOT_PID..."
    if ps -p $BOT_PID > /dev/null; then
        kill $BOT_PID
        echo "✅ Процесс с PID $BOT_PID остановлен."
    else
        echo "⚠️ Процесс с PID $BOT_PID не найден."
    fi
    rm -f bot_pid.txt
fi

# Остановка любых оставшихся процессов бота
echo "Поиск и остановка всех процессов бота..."
pkill -f "python3 pokemon_bot_workflow.py" || true
pkill -f "python3 run_bot_forever.py" || true
sleep 1

# Остановка воркфлоу через файл .run (на всякий случай)
if [ -f ".replit.d/rundata/pokemon_bot.run" ]; then
    echo "Остановка воркфлоу 'pokemon_bot'..."
    rm -f ".replit.d/rundata/pokemon_bot.run"
    echo "✅ Файл запуска воркфлоу удален."
fi

# Удаление heartbeat файла
if [ -f "bot_running.txt" ]; then
    echo "Удаление файла heartbeat..."
    rm -f bot_running.txt
    echo "✅ Файл heartbeat удален."
fi

echo ""
echo "===== Бот остановлен ====="
echo "Для проверки статуса бота, выполните:"
echo "python3 check_bot_status.py"