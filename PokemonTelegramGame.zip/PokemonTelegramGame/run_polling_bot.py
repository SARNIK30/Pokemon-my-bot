#!/usr/bin/env python3
"""
Скрипт для запуска Телеграм Бота Покемонов в режиме поллинга.
Оптимизирован для выполнения в воркфлоу Replit.
"""

import asyncio
import logging
import sys
import signal
import time
import traceback
from bot import run_polling

# Настройка логирования с большей детализацией
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pokemon_bot_debug.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

# Настраиваем уровни логирования для различных модулей
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.INFO)
logging.getLogger("asyncio").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("handlers.start").setLevel(logging.DEBUG)
logging.getLogger("storage").setLevel(logging.DEBUG)

logger = logging.getLogger(__name__)
should_stop = False

def signal_handler(sig, frame):
    """Обработчик сигналов для корректного завершения бота."""
    global should_stop
    logger.info("Получен сигнал завершения. Остановка бота...")
    should_stop = True

async def main():
    """Основная функция для запуска бота с обработкой перезапуска."""
    global should_stop
    
    # Регистрируем обработчики сигналов
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Создаем файл для отслеживания статуса бота
    try:
        with open("bot_running.txt", "w") as f:
            f.write(f"Bot started at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    except Exception as e:
        logger.error(f"Ошибка при создании файла статуса: {e}")
    
    retry_count = 0
    max_retries = 5
    wait_time = 5
    
    logger.info("Запуск Телеграм Бота Покемонов в режиме поллинга...")
    logger.info("Для остановки используйте Ctrl+C")
    
    while not should_stop:
        try:
            await run_polling()
            
            # Если бот завершился без ошибки, но мы не хотели его остановить
            if not should_stop:
                logger.warning("Бот неожиданно завершился. Перезапуск...")
                await asyncio.sleep(5)
                
        except Exception as e:
            retry_count += 1
            logger.error(f"Ошибка при работе бота: {e}")
            logger.error(f"Подробный трейс: {traceback.format_exc()}")
            
            if retry_count >= max_retries:
                logger.warning(f"Достигнуто максимальное количество попыток ({max_retries}). Пауза 30 секунд...")
                await asyncio.sleep(30)
                retry_count = 0
                wait_time = 5
            else:
                logger.info(f"Попытка перезапуска {retry_count}/{max_retries} через {wait_time} секунд...")
                await asyncio.sleep(wait_time)
                wait_time = min(60, wait_time * 2)  # Увеличиваем время ожидания между попытками
    
    # Удаляем файл статуса при остановке
    try:
        import os
        if os.path.exists("bot_running.txt"):
            os.remove("bot_running.txt")
    except Exception as e:
        logger.error(f"Ошибка при удалении файла статуса: {e}")
    
    logger.info("Бот остановлен.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Бот остановлен вручную.")
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        sys.exit(1)
