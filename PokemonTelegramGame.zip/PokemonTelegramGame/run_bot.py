#!/usr/bin/env python3
"""
Скрипт для запуска Телеграм Бота Покемонов с вебхуком.
Оптимизирован для использования в продакшене.
"""

import logging
import sys
from main import app

if __name__ == "__main__":
    # Configure logging to show INFO level logs
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        stream=sys.stdout
    )
    
    # Run the Flask app with the webhook
    print("Запуск Телеграм Бота Покемонов с вебхуком...")
    print("Токен бота и URL вебхука загружаются из переменных окружения")
    app.run(host="0.0.0.0", port=5000)
