#!/bin/bash

# Устанавливаем цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}=====================================${NC}"
echo -e "${YELLOW}   Остановка Telegram Pokemon Bot   ${NC}"
echo -e "${YELLOW}=====================================${NC}"

# Проверяем, запущен ли бот
if [ ! -f bot.pid ]; then
  echo -e "${YELLOW}Бот не запущен (файл bot.pid не найден)${NC}"
  
  # Пытаемся найти процесс по имени
  PYTHON_PIDS=$(ps aux | grep "python run_bot_workflow.py" | grep -v grep | awk '{print $2}')
  
  if [ ! -z "$PYTHON_PIDS" ]; then
    echo -e "${YELLOW}Найдены процессы бота без файла PID. Попытка остановки...${NC}"
    
    for pid in $PYTHON_PIDS; do
      echo -e "${YELLOW}Останавливаем процесс с PID ${pid}...${NC}"
      kill $pid
      sleep 1
    done
    
    echo -e "${GREEN}Все найденные процессы остановлены.${NC}"
  else
    echo -e "${RED}Не найдено активных процессов бота.${NC}"
    exit 1
  fi
  exit 0
fi

PID=$(cat bot.pid)

# Проверяем, существует ли процесс с таким PID
if ! ps -p $PID > /dev/null; then
  echo -e "${YELLOW}Процесс с PID $PID не найден. Возможно, бот уже остановлен.${NC}"
  rm bot.pid
  
  # Проверяем наличие дополнительных файлов состояния
  if [ -f bot_heartbeat.txt ]; then
    rm bot_heartbeat.txt
    echo "Файл контроля состояния удален."
  fi
  
  if [ -f bot_running.txt ]; then
    rm bot_running.txt
    echo "Файл контроля запуска удален."
  fi
  
  exit 0
fi

# Останавливаем бота
echo -e "${YELLOW}Останавливаем Pokemon Bot (PID: $PID)...${NC}"
kill $PID

# Ждем завершения процесса
sleep 2

# Проверяем, завершился ли процесс
if ps -p $PID > /dev/null; then
  echo -e "${RED}Процесс не завершился. Принудительное завершение...${NC}"
  kill -9 $PID
  sleep 1
  
  # Финальная проверка
  if ps -p $PID > /dev/null; then
    echo -e "${RED}Не удалось остановить процесс. Пожалуйста, проверьте вручную.${NC}"
  else
    echo -e "${GREEN}Бот принудительно остановлен.${NC}"
  fi
else
  echo -e "${GREEN}Бот корректно остановлен.${NC}"
fi

# Удаляем файл PID
rm bot.pid
echo -e "${GREEN}Файл PID удален.${NC}"

# Удаляем дополнительные файлы состояния
if [ -f bot_heartbeat.txt ]; then
  rm bot_heartbeat.txt
  echo "Файл контроля состояния удален."
fi

if [ -f bot_running.txt ]; then
  rm bot_running.txt
  echo "Файл контроля запуска удален."
fi

echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}Бот остановлен. Для запуска используйте:${NC}"
echo "./start_pokebot.sh"
echo -e "${GREEN}=====================================${NC}"