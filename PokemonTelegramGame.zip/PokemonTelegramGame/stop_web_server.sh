#!/bin/bash
# Скрипт для остановки веб-сервера мониторинга бота

echo "Остановка веб-сервера для мониторинга..."

# Остановка процесса по PID, сохраненному в файле
if [ -f web_server_pid.txt ]; then
    pid=$(cat web_server_pid.txt)
    if ps -p $pid > /dev/null; then
        echo "Остановка веб-сервера с PID: $pid..."
        kill $pid
        echo "Процесс остановлен."
    else
        echo "Процесс с PID $pid не найден."
    fi
    rm web_server_pid.txt
else
    echo "Файл с PID не найден. Возможно, сервер не запущен."
fi

echo "Веб-сервер остановлен."