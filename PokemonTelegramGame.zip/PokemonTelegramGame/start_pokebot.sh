#!/bin/bash

# Устанавливаем цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}   Запуск Telegram Pokemon Bot      ${NC}"
echo -e "${GREEN}=====================================${NC}"

# Проверка доступности переменных окружения
if [ -z "$BOT_TOKEN" ]; then
    echo -e "${RED}ОШИБКА: Переменная окружения BOT_TOKEN не найдена!${NC}"
    echo "Убедитесь, что токен бота настроен в конфигурации проекта."
    exit 1
fi

# Убедимся, что скрипт запуска исполняемый
chmod +x run_bot_background.sh

# Создаем папку для данных, если она не существует
if [ ! -d "data" ]; then
    echo "Создаем директорию для данных..."
    mkdir -p data
fi

# Останавливаем предыдущую версию бота, если она была запущена
if [ -f bot.pid ]; then
  if ps -p $(cat bot.pid) > /dev/null; then
    echo -e "${YELLOW}Останавливаем предыдущую версию бота...${NC}"
    kill $(cat bot.pid)
    sleep 3
    
    # Проверяем, что процесс действительно остановлен
    if ps -p $(cat bot.pid) > /dev/null; then
      echo -e "${YELLOW}Процесс не остановился. Принудительное завершение...${NC}"
      kill -9 $(cat bot.pid)
      sleep 1
    fi
  fi
  rm bot.pid
fi

# Запускаем бота в фоновом режиме
echo -e "${GREEN}Запускаем Pokemon Bot...${NC}"
./run_bot_background.sh

# Проверяем, успешно ли запустился бот
if [ -f bot.pid ] && ps -p $(cat bot.pid) > /dev/null; then
    echo -e "${GREEN}Бот успешно запущен с PID $(cat bot.pid)!${NC}"
    echo ""
    echo -e "${GREEN}Для проверки статуса используйте:${NC}"
    echo "ps aux | grep $(cat bot.pid)"
    echo -e "${GREEN}Для просмотра логов используйте:${NC}"
    echo "tail -f pokemon_bot.log"
    echo -e "${GREEN}Для остановки бота используйте:${NC}"
    echo "./stop_pokebot.sh"
else
    echo -e "${RED}Ошибка при запуске бота. Проверьте логи для получения дополнительной информации:${NC}"
    echo "tail -f pokemon_bot.log"
    exit 1
fi

echo -e "${GREEN}=====================================${NC}"