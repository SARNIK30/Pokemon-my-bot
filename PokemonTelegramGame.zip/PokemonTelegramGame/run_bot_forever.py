#!/usr/bin/env python3
"""
Скрипт для постоянного запуска Telegram бота Pokemon в режиме поллинга.
Разработан для работы в Replit 24/7 с автоматическим перезапуском при ошибках.
"""

import asyncio
import datetime
import logging
import os
import signal
import sys
import time
import traceback

from telegram.ext import ApplicationBuilder

from bot import error_handler, register_handlers
from config import BOT_TOKEN

# Настройка логирования
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[
        logging.FileHandler("pokemon_bot.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Счетчик перезапусков
restart_count = 0
# Время последнего перезапуска
last_restart_time = time.time()
# Максимальное количество перезапусков в течение RESTART_WINDOW
MAX_RESTARTS = 5
# Окно времени для отслеживания перезапусков (в секундах)
RESTART_WINDOW = 60


async def run_polling_bot():
    """Запуск бота в режиме поллинга."""
    logger.info("Запуск бота в режиме поллинга...")
    
    try:
        # Создаем приложение бота
        application = ApplicationBuilder().token(BOT_TOKEN).build()
        
        # Регистрируем обработчики команд и сообщений
        register_handlers(application)
        
        # Устанавливаем обработчик ошибок
        application.add_error_handler(error_handler)
        
        # Запускаем бота в режиме поллинга с более широким списком разрешенных обновлений
        await application.initialize()
        await application.start()
        await application.updater.start_polling(
            allowed_updates=["message", "callback_query", "inline_query", "chat_member", "chat_join_request"]
        )
        
        logger.info("Поллинг бота успешно запущен. Бот работает.")
        
        # Бесконечный цикл для поддержания бота активным
        while True:
            await asyncio.sleep(10)  # Продолжаем выполнение каждые 10 секунд
            
    except Exception as e:
        logger.error(f"Ошибка при запуске поллинга: {e}")
        logger.error(traceback.format_exc())
        raise  # Пробрасываем исключение для обработки в main_loop
    finally:
        # Корректное завершение бота
        try:
            logger.info("Остановка бота...")
            await application.stop()
            await application.shutdown()
        except Exception as e:
            logger.error(f"Ошибка при остановке бота: {e}")
            pass


async def main_loop():
    """Основной цикл с перезапуском бота при ошибках."""
    global restart_count, last_restart_time
    
    while True:
        try:
            # Проверяем, не превышен ли лимит перезапусков
            current_time = time.time()
            if current_time - last_restart_time > RESTART_WINDOW:
                # Сбрасываем счетчик, если прошло больше времени, чем RESTART_WINDOW
                restart_count = 0
                last_restart_time = current_time
            
            if restart_count >= MAX_RESTARTS:
                # Если превышен лимит перезапусков, ждем некоторое время
                wait_time = 60  # Ждем 1 минуту перед следующей попыткой
                logger.warning(f"Превышен лимит перезапусков. Ожидание {wait_time} секунд...")
                await asyncio.sleep(wait_time)
                # Сбрасываем счетчик перезапусков
                restart_count = 0
                last_restart_time = time.time()
            
            # Запускаем бота
            start_time = datetime.datetime.now()
            logger.info(f"Запуск бота (попытка #{restart_count + 1}): {start_time}")
            
            await run_polling_bot()
            
        except KeyboardInterrupt:
            logger.info("Получен сигнал прерывания. Завершение работы...")
            break
        except Exception as e:
            # Увеличиваем счетчик перезапусков
            restart_count += 1
            
            # Логируем ошибку
            logger.error(f"Ошибка в работе бота: {e}")
            logger.error(traceback.format_exc())
            
            # Ждем немного перед перезапуском
            wait_time = min(5 * restart_count, 30)  # Максимум 30 секунд
            logger.info(f"Перезапуск через {wait_time} секунд...")
            await asyncio.sleep(wait_time)


def signal_handler(sig, frame):
    """Обработчик сигналов для корректного завершения бота."""
    logger.info(f"Получен сигнал {sig}. Завершение работы...")
    sys.exit(0)


if __name__ == "__main__":
    # Установка обработчиков сигналов
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("===== Запуск бота Pokemon в режиме 24/7 =====")
    logger.info(f"Версия Python: {sys.version}")
    logger.info(f"Время запуска: {datetime.datetime.now()}")
    
    # Запуск основного цикла
    try:
        asyncio.run(main_loop())
    except KeyboardInterrupt:
        logger.info("Получен сигнал прерывания. Завершение работы...")
    except Exception as e:
        logger.critical(f"Критическая ошибка: {e}")
        logger.critical(traceback.format_exc())
    
    logger.info("===== Бот завершил работу =====")